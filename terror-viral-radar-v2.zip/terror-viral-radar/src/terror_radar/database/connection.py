import sqlite3
from ..config import DB_PATH
SCHEMA='''
CREATE TABLE IF NOT EXISTS channels(id INTEGER PRIMARY KEY,youtube_id TEXT UNIQUE,name TEXT,url TEXT,subscribers INTEGER DEFAULT 0,median_views REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS shorts(id INTEGER PRIMARY KEY,channel_id INTEGER NOT NULL,video_id TEXT UNIQUE,title TEXT,url TEXT,published_at TEXT,duration REAL DEFAULT 0,views INTEGER DEFAULT 0,likes INTEGER DEFAULT 0,comments INTEGER DEFAULT 0,description TEXT,thumbnail_url TEXT,transcript TEXT DEFAULT '',FOREIGN KEY(channel_id) REFERENCES channels(id));
CREATE TABLE IF NOT EXISTS snapshots(id INTEGER PRIMARY KEY,short_id INTEGER,observed_at TEXT DEFAULT CURRENT_TIMESTAMP,views INTEGER,likes INTEGER,comments INTEGER);
CREATE TABLE IF NOT EXISTS analyses(short_id INTEGER PRIMARY KEY,relative_performance REAL,velocity_percentile REAL,engagement REAL,outlier_score REAL,hook_score REAL,topic_score REAL,structure_score REAL,novelty_score REAL,viral_score REAL,confidence REAL,hook_type TEXT,topic TEXT,format TEXT,reason TEXT);
CREATE INDEX IF NOT EXISTS idx_shorts_channel ON shorts(channel_id); CREATE INDEX IF NOT EXISTS idx_snapshots_short ON snapshots(short_id);'''
def connect():
 DB_PATH.parent.mkdir(parents=True,exist_ok=True); c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; c.executescript(SCHEMA); return c
