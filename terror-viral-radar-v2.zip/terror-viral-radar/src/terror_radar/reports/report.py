from ..database.connection import connect
def top_shorts(limit=50):
 c=connect(); rows=c.execute('SELECT s.*,a.viral_score,a.confidence,a.hook_type,a.topic,a.format,a.reason FROM analyses a JOIN shorts s ON s.id=a.short_id ORDER BY a.viral_score DESC LIMIT ?',(limit,)).fetchall(); c.close(); return rows
def patterns(limit=20):
 c=connect(); rows=c.execute('SELECT topic,format,COUNT(*) n,AVG(viral_score) score FROM analyses GROUP BY topic,format ORDER BY score DESC LIMIT ?',(limit,)).fetchall(); c.close(); return rows
