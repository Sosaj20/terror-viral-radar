import math
from .metrics import engagement,views_per_day
from .hooks import classify
from .features import classify_topic,classify_format,novelty
def percentile(v,vals): return 50.0 if not vals else 100*sum(x<=v for x in vals)/len(vals)
def analyze_row(row,peers):
 views=[r['views'] or 0 for r in peers]; med=max(1,sorted(views)[len(views)//2] if views else 1)
 rel=(row['views'] or 0)/med; rel_score=min(100,50+25*math.log10(max(1,rel)))
 vel=views_per_day(row['views'],row['published_at']); velocity=percentile(vel,[views_per_day(r['views'],r['published_at']) for r in peers])
 eng=engagement(row['likes'],row['comments'],row['views'])*100
 hook_type,hook=classify((row['title'] or '')+' '+(row['transcript'] or ''))
 text=' '.join(x or '' for x in (row['title'],row['description'],row['transcript']))
 topic=classify_topic(text); fmt=classify_format(text); nov=novelty(text,[' '.join(x or '' for x in (r['title'],r['description'])) for r in peers if r['id']!=row['id']])
 d=row['duration'] or 0; structure=90 if 8<=d<=25 else (75 if 5<=d<=40 else 55)
 outlier=min(100,max(0,50+25*math.log10(max(1,rel))))
 score=rel_score*.22+velocity*.22+eng*.14+outlier*.12+hook*.12+75*.06+structure*.07+nov*.05
 conf=min(100,45+min(40,len(peers))*1.2+hook*.15)
 reason=f'{topic}/{fmt}; hook={hook_type}; relative={rel_score:.0f}; velocity={velocity:.0f}; engagement={eng:.1f}'
 return score,conf,(rel_score,velocity,eng,outlier,hook,75,structure,nov,hook_type,topic,fmt,reason)
