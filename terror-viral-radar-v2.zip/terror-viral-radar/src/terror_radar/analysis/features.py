import re
TOPICS={"cctv":["cctv","cámara","camera","security footage"],"found_footage":["found footage","grabación","recording"],"haunted_house":["casa embrujada","haunted house","casa abandonada"],"creature":["criatura","creature","monstruo","monster","entidad"],"hospital":["hospital","enfermera","nurse","paciente"],"forest":["bosque","forest","woods","carretera"],"emergency_call":["llamada","call","911","emergencia"],"photograph":["foto","photograph","picture","imagen"],"elevator":["ascensor","elevator"],"cemetery":["cementerio","cemetery","tumba","grave"],"police":["policía","police","oficial"]}
FORMATS={"pov":["pov","imagina que eres","you are"],"cctv":["cctv","camera","cámara"],"found_footage":["found footage","grabación"],"phone_call":["llamada","call","telefono","phone"],"chat":["chat","mensaje","message","text"],"testimony":["me pasó","it happened to me","true story","historia real"]}
def classify_topic(text):
 t=(text or '').lower(); scores={k:sum(t.count(x) for x in v) for k,v in TOPICS.items()}; return max(scores,key=scores.get) if max(scores.values(),default=0) else 'general_terror'
def classify_format(text):
 t=(text or '').lower(); scores={k:sum(t.count(x) for x in v) for k,v in FORMATS.items()}; return max(scores,key=scores.get) if max(scores.values(),default=0) else 'narration'
def novelty(text,corpus):
 words=set(re.findall(r'[a-záéíóúñ]{4,}',(text or '').lower()))
 if not words or not corpus:return 60.0
 sims=[]
 for other in corpus:
  ow=set(re.findall(r'[a-záéíóúñ]{4,}',(other or '').lower())); sims.append(len(words&ow)/max(1,len(words|ow)))
 return max(0,min(100,100*(1-max(sims))))
