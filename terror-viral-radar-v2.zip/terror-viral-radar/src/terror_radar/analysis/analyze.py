from .viral_score import analyze_row
from ..database.connection import connect
def analyze_all():
 c=connect(); n=0
 for ch in c.execute('SELECT * FROM channels').fetchall():
  rows=c.execute('SELECT * FROM shorts WHERE channel_id=?',(ch['id'],)).fetchall()
  for r in rows:
   score,conf,d=analyze_row(r,rows)
   c.execute('INSERT OR REPLACE INTO analyses(short_id,relative_performance,velocity_percentile,engagement,outlier_score,hook_score,topic_score,structure_score,novelty_score,viral_score,confidence,hook_type,topic,format,reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(r['id'],*d[:8],score,conf,d[8],d[9],d[10],d[11])); n+=1
 c.commit(); c.close(); return n
