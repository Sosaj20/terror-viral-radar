# 👻 Terror Viral Radar V2

Máquina para encontrar Shorts de terror que rinden excepcionalmente bien respecto a su canal.

Pipeline: canal → Shorts → metadata → snapshots → normalización → outliers → hooks → temas → formatos → Viral Potential Score → patrones.

Score V2: rendimiento relativo, velocidad, engagement, outlier, hook, tema, estructura, novedad y confianza.

```bash
pip install -e .
terror-radar add-channel "https://www.youtube.com/@Canal"
terror-radar analyze
terror-radar viral --limit 50
terror-radar web
```

La puntuación es heurística y sirve para priorizar investigación; no garantiza viralidad.
