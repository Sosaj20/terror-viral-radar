# Terror Viral Radar

V1: escaneo de canales, Shorts, metadata, SQLite, métricas, hooks, Viral Potential Score y dashboard.

## Instalación
```bash
python -m venv .venv
pip install -e .
```

## Uso
```bash
terror-radar add-channel "https://www.youtube.com/@Canal"
terror-radar analyze
terror-radar viral
terror-radar web
```
