from terror_radar.analysis.hooks import classify
def test_camera_hook(): assert classify('Esta cámara grabó algo')[0]=='camera'
