from terror_radar.analysis.metrics import engagement
def test_engagement(): assert engagement(100,50,10000)==.015
