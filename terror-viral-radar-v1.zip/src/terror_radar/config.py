from pathlib import Path
import os
ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/"data"
DB_PATH=Path(os.getenv("DATABASE_PATH",str(DATA/"terror_radar.db")))
DATA.mkdir(exist_ok=True)
