from ..database.connection import connect
def top_shorts(limit=50):
    c=connect()
    rows=c.execute("SELECT s.*,a.viral_score,a.confidence,a.hook_type,c.name channel FROM analyses a JOIN shorts s ON s.id=a.short_id JOIN channels c ON c.id=s.channel_id ORDER BY a.viral_score DESC LIMIT ?",(limit,)).fetchall()
    c.close();return rows
