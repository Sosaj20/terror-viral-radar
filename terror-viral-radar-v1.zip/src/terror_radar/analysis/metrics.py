from datetime import datetime,timezone
def engagement(likes,comments,views): return 0 if not views else min(1,(likes+comments)/views)
def views_per_day(views,published):
    if not published:return float(views or 0)
    try:
        d=datetime.strptime(published[:8],"%Y%m%d").replace(tzinfo=timezone.utc)
        return (views or 0)/max(1,(datetime.now(timezone.utc)-d).days)
    except Exception:return float(views or 0)
