import math
from .metrics import engagement,views_per_day
from .hooks import classify
def score(row,views):
    med=max(1,sorted(views)[len(views)//2] if views else 1)
    rel=(row["views"] or 0)/med
    rel_score=min(100,50+15*math.log10(max(1,rel)))
    hook_type,hook=classify(row["transcript"] or row["title"] or "")
    eng=engagement(row["likes"],row["comments"],row["views"])*100
    structure=90 if 8<=row["duration"]<=25 else 60
    total=rel_score*.25+50*.20+eng*.15+hook*.15+75*.10+structure*.10+60*.05
    return total,(rel_score,hook,eng,structure,hook_type)
