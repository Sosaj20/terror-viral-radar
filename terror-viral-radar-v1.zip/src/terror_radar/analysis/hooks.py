import re
PATTERNS=[("time_specific",r"\b(?:a las|at)\s+\d"),("camera",r"\b(?:cámara|camera|cctv|footage|grabación|recording)\b"),("warning",r"\b(?:nunca|never|no hagas|don't|si escuchas|if you hear)\b"),("curiosity_gap",r"\b(?:nadie sabe|no one knows|esto ocurrió|this happened)\b"),("direct_threat",r"\b(?:detrás de ti|behind you|te está mirando|it's watching)\b")]
def classify(text):
    hits=[n for n,p in PATTERNS if re.search(p,(text or "")[:300].lower())]
    return hits[0] if hits else "open_loop",min(100,55+15*len(hits))
