from .viral_score import score
from ..database.connection import connect
def analyze_all():
    c=connect();n=0
    for ch in c.execute("SELECT * FROM channels"):
        rows=c.execute("SELECT * FROM shorts WHERE channel_id=?",(ch["id"],)).fetchall();views=[r["views"] or 0 for r in rows]
        for r in rows:
            total,(rel,hook,eng,structure,ht)=score(r,views)
            c.execute("INSERT OR REPLACE INTO analyses VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(r["id"],rel,50,eng,hook,75,structure,60,total,70+hook*.25,ht,"terror","short"));n+=1
    c.commit();c.close();return n
