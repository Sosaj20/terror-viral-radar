from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from ..reports.report import top_shorts
app=FastAPI(title="Terror Viral Radar")
@app.get("/",response_class=HTMLResponse)
def index():
    rows=top_shorts(100)
    lines=[]
    for i,r in enumerate(rows,1):
        lines.append("<tr><td>%s</td><td>%.1f</td><td>%s</td><td>%s</td><td>%s</td></tr>"%(i,r["viral_score"],r["title"] or "",f'{r["views"]:,}',r["hook_type"]))
    return "<html><body><h1>Terror Viral Radar</h1><table><tr><th>#</th><th>Score</th><th>Título</th><th>Views</th><th>Hook</th></tr>"+''.join(lines)+"</table></body></html>"
def run():
    import uvicorn;uvicorn.run(app,host="127.0.0.1",port=8000)
