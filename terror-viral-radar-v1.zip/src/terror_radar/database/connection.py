import sqlite3
from ..config import DB_PATH
SCHEMA='''CREATE TABLE IF NOT EXISTS channels(id INTEGER PRIMARY KEY,youtube_id TEXT UNIQUE,name TEXT,url TEXT,subscribers INTEGER DEFAULT 0,median_views REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS shorts(id INTEGER PRIMARY KEY,channel_id INTEGER,video_id TEXT UNIQUE,title TEXT,url TEXT,published_at TEXT,duration REAL DEFAULT 0,views INTEGER DEFAULT 0,likes INTEGER DEFAULT 0,comments INTEGER DEFAULT 0,description TEXT,thumbnail_url TEXT,transcript TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS analyses(short_id INTEGER PRIMARY KEY,relative_performance REAL,views_per_day REAL,engagement REAL,hook_score REAL,topic_score REAL,structure_score REAL,novelty_score REAL,viral_score REAL,confidence REAL,hook_type TEXT,topic TEXT,format TEXT);'''
def connect():
    DB_PATH.parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(DB_PATH);c.row_factory=sqlite3.Row;c.executescript(SCHEMA);return c
