import argparse
def main():
    p=argparse.ArgumentParser();s=p.add_subparsers(dest="cmd")
    a=s.add_parser("add-channel");a.add_argument("url")
    s.add_parser("analyze");v=s.add_parser("viral");v.add_argument("--limit",type=int,default=20);s.add_parser("web")
    x=p.parse_args()
    if x.cmd=="add-channel":
        from .ingestion.channel import add_channel;print("Entradas:",add_channel(x.url))
    elif x.cmd=="analyze":
        from .analysis.analyze import analyze_all;print("Analizados:",analyze_all())
    elif x.cmd=="viral":
        from .reports.report import top_shorts
        for i,r in enumerate(top_shorts(x.limit),1): print(f"{i:03} | {r['viral_score']:.1f} | {r['views']:,} | {r['title']}")
    elif x.cmd=="web":
        from .web.app import run;run()
    else:p.print_help()
