from terror_radar.features.text import hook
def test_warning():
    assert hook("Nunca hagas esto")[0]=="warning"
