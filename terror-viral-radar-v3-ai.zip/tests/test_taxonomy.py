from terror_radar.classifiers.taxonomy import classify
def test_cctv():
    assert classify("Esta cámara de seguridad")[0]=="cctv"
