# Proveedores de IA

Terror Viral Radar puede usar una cuenta propia de OpenAI, Gemini o Claude.

## OpenAI
```bash
pip install -e ".[openai]"
```
`.env`:
```env
AI_PROVIDER=openai
AI_API_KEY=...
AI_MODEL=gpt-5-mini
```

## Gemini
```bash
pip install -e ".[gemini]"
```
```env
AI_PROVIDER=gemini
AI_API_KEY=...
AI_MODEL=gemini-2.5-flash
```

## Claude
```bash
pip install -e ".[claude]"
```
```env
AI_PROVIDER=claude
AI_API_KEY=...
AI_MODEL=claude-sonnet-4-20250514
```

## Análisis
```bash
terror-radar ai-analyze
terror-radar ai-ideas --count 30
```

Las claves se usan desde tu entorno local y no se incluyen en el repositorio.
