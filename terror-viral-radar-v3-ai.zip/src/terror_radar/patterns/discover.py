from collections import defaultdict
from ..database.connection import connect
def discover():
    c=connect();rows=c.execute("SELECT a.*,s.views FROM analyses a JOIN shorts s ON s.id=a.short_id").fetchall()
    buckets=defaultdict(list)
    for r in rows:
        buckets[("topic",r["topic"])].append(r)
        buckets[("format",r["format"])].append(r)
        buckets[("hook",r["hook_type"])].append(r)
    c.execute("DELETE FROM patterns")
    for (typ,key),items in buckets.items():
        avg=sum(x["viral_score"] for x in items)/len(items)
        views=sum(x["views"] or 0 for x in items)/len(items)
        c.execute("INSERT OR REPLACE INTO patterns(pattern_type,pattern_key,frequency,avg_score,avg_views,description) VALUES(?,?,?,?,?,?)",
                  (typ,key,len(items),avg,views,f"{key}: {len(items)} Shorts, score medio {avg:.1f}"))
    c.commit();out=c.execute("SELECT * FROM patterns ORDER BY avg_score DESC").fetchall();c.close();return out
