from pathlib import Path
import yaml
ROOT=Path(__file__).resolve().parents[3]
cfg=yaml.safe_load((ROOT/"config/taxonomy.yaml").read_text(encoding="utf8"))
def classify(text):
    t=(text or "").lower()
    topics=[(k,sum(1 for x in v if x.lower() in t)) for k,v in cfg["topics"].items()]
    formats=[(k,sum(1 for x in v if x.lower() in t)) for k,v in cfg["formats"].items()]
    topic=max(topics,key=lambda x:x[1]) if topics else ("other",0)
    fmt=max(formats,key=lambda x:x[1]) if formats else ("other",0)
    return topic[0] if topic[1] else "other",fmt[0] if fmt[1] else "other"
