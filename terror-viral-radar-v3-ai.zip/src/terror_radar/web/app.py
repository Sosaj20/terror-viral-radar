from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from ..database.connection import connect
app=FastAPI(title="Terror Viral Radar V3")
@app.get("/",response_class=HTMLResponse)
def index():
    c=connect()
    rows=c.execute("SELECT s.title,s.views,a.viral_score,a.confidence,a.hook_type,a.topic,a.format,c.name channel FROM shorts s JOIN analyses a ON a.short_id=s.id JOIN channels c ON c.id=s.channel_id ORDER BY a.viral_score DESC LIMIT 100").fetchall()
    c.close()
    trs="".join(f"<tr><td>{i}</td><td>{r['viral_score']:.1f}</td><td>{r['confidence']:.0f}</td><td>{r['views']:,}</td><td>{r['title'] or ''}</td><td>{r['hook_type']}</td><td>{r['topic']}</td><td>{r['format']}</td></tr>" for i,r in enumerate(rows,1))
    return "<html><body style='font-family:system-ui;background:#111;color:#eee;padding:30px'><h1>👻 Terror Viral Radar V3</h1><table style='width:100%'><tr><th>#</th><th>Score</th><th>Conf.</th><th>Views</th><th>Título</th><th>Hook</th><th>Tema</th><th>Formato</th></tr>"+trs+"</table></body></html>"
def run():
    import uvicorn
    uvicorn.run(app,host="127.0.0.1",port=8000)
