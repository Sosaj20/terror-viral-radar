# Adapter preparado para conectar un transcriptor externo.
# En V3 AI el análisis acepta transcript almacenado en shorts.transcript.
# La fuente puede ser Whisper, YouTube captions u otro servicio.
from ..database.connection import connect
def set_transcript(video_id,text):
    c=connect();c.execute("UPDATE shorts SET transcript=? WHERE video_id=?",(text,video_id));c.commit();c.close()
