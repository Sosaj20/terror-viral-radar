from ..database.connection import connect
TEMPLATES={
"cctv":"La cámara grabó algo que nadie debía ver",
"found_footage":"Encontraron esta grabación y hay un detalle imposible",
"paranormal":"Algo apareció durante la grabación y nadie sabe por qué",
"creature":"La criatura solo aparece cuando la cámara deja de moverse",
"haunted_place":"Entraron al lugar abandonado y cometieron un error",
"forest":"Escucharon una voz en el bosque y siguieron el sonido",
"emergency":"La llamada de emergencia terminó de una forma inexplicable",
"photograph":"En esta foto apareció alguien que no estaba allí"
}
def generate(limit=20):
    c=connect();ps=c.execute("SELECT * FROM patterns ORDER BY avg_score DESC LIMIT ?",(limit,)).fetchall()
    c.execute("DELETE FROM ideas")
    for p in ps:
        topic=p["pattern_key"] if p["pattern_type"]=="topic" else "paranormal"
        title=TEMPLATES.get(topic,"Algo aterrador quedó registrado por accidente")
        c.execute("INSERT INTO ideas(title,hook,topic,format,rationale,source_pattern) VALUES(?,?,?,?,?,?)",
                  (title,"No mires el fondo hasta el segundo final.",topic,"short",p["description"],p["pattern_key"]))
    c.commit();rows=c.execute("SELECT * FROM ideas ORDER BY id DESC").fetchall();c.close();return rows
