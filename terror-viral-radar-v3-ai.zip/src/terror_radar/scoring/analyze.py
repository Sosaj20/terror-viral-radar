from ..database.connection import connect
from .score import calculate
def analyze_all():
    c=connect();n=0
    for ch in c.execute("SELECT id FROM channels"):
        rows=[dict(r) for r in c.execute("SELECT * FROM shorts WHERE channel_id=?",(ch["id"],)).fetchall()]
        for r in rows:
            total,conf,x=calculate(r,rows)
            c.execute("INSERT OR REPLACE INTO analyses VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (r["id"],x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],x[8],total,conf,x[9],x[10],x[11]))
            n+=1
    c.commit();c.close();return n
