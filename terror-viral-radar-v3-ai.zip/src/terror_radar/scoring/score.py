import math
from ..features.text import hook
from ..classifiers.taxonomy import classify
def calculate(row,rows):
    views=[r["views"] or 0 for r in rows]
    med=max(1,sorted(views)[len(views)//2] if views else 1)
    rel=(row["views"] or 0)/med
    relative=min(100,50+20*math.log10(max(1,rel)))
    engagement=min(100,((row["likes"] or 0)+(row["comments"] or 0))/max(1,row["views"] or 1)*100)
    h,hs=hook((row["title"] or "")+" "+(row["description"] or "")+" "+(row["transcript"] or ""))
    topic,fmt=classify((row["title"] or "")+" "+(row["description"] or ""))
    structure=90 if 8<=row["duration"]<=25 else 65
    velocity=50
    outlier=relative
    novelty=70
    total=relative*.24+velocity*.20+engagement*.14+outlier*.14+hs*.10+75*.06+75*.05+novelty*.04+structure*.03
    confidence=min(99,55+(10 if row["transcript"] else 0))
    return total,confidence,(relative,velocity,engagement,outlier,hs,75,75,novelty,structure,h,topic,fmt)
