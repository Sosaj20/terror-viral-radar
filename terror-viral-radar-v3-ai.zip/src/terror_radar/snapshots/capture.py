from datetime import datetime,timezone
from ..database.connection import connect
from ..ingestion.youtube import extract_video
def capture_all():
    c=connect();rows=c.execute("SELECT id,url FROM shorts").fetchall();n=0
    for r in rows:
        try:
            x=extract_video(r["url"])
            c.execute("INSERT INTO snapshots(short_id,captured_at,views,likes,comments) VALUES(?,?,?,?,?)",
                      (r["id"],datetime.now(timezone.utc).isoformat(),x.get("view_count") or 0,x.get("like_count") or 0,x.get("comment_count") or 0))
            c.execute("UPDATE shorts SET views=?,likes=?,comments=? WHERE id=?",
                      (x.get("view_count") or 0,x.get("like_count") or 0,x.get("comment_count") or 0,r["id"]))
            n+=1
        except Exception: pass
    c.commit();c.close();return n
