import csv,json
from pathlib import Path
from ..database.connection import connect
def export_json(path="data/exports/ranking.json"):
    Path(path).parent.mkdir(parents=True,exist_ok=True);c=connect()
    rows=[dict(x) for x in c.execute("SELECT s.*,a.viral_score,a.confidence,a.hook_type,a.topic,a.format FROM shorts s JOIN analyses a ON a.short_id=s.id ORDER BY a.viral_score DESC")]
    Path(path).write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding="utf8");c.close();return path
def export_csv(path="data/exports/ranking.csv"):
    Path(path).parent.mkdir(parents=True,exist_ok=True);c=connect()
    rows=[dict(x) for x in c.execute("SELECT s.title,s.url,s.views,a.viral_score,a.confidence,a.hook_type,a.topic,a.format FROM shorts s JOIN analyses a ON a.short_id=s.id ORDER BY a.viral_score DESC")]
    if rows:
        with open(path,"w",newline="",encoding="utf8") as f:
            w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    c.close();return path
