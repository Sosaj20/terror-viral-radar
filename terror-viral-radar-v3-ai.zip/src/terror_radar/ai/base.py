from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

@dataclass
class AIResult:
    provider: str
    model: str
    data: dict[str, Any]
    raw: str = ""

class AIProvider(ABC):
    name="base"
    def __init__(self, api_key:str, model:str|None=None): self.api_key=api_key; self.model=model
    @abstractmethod
    def analyze_short(self, title:str, description:str="", transcript:str="")->AIResult: ...
    @abstractmethod
    def generate_ideas(self, patterns:list[dict], count:int=20)->AIResult: ...
