ANALYZE_PROMPT = '''Analiza este Short de terror como estratega de contenido viral.
Devuelve SOLO JSON válido con:
hook_type, hook_strength, topic, format, narrative_structure, curiosity_gap,
fear_mechanism, twist, retention_risk, originality, viral_reasons, reusable_patterns.
No copies frases exactas; identifica principios reutilizables.

TÍTULO:
{title}

DESCRIPCIÓN:
{description}

TRANSCRIPCIÓN:
{transcript}
'''

IDEAS_PROMPT = '''Genera {count} conceptos ORIGINALES de Shorts de terror basados en estos patrones.
No copies títulos, frases ni historias concretas. Recombina patrones.
Devuelve SOLO un JSON con {"ideas":[...]}.
Cada idea debe tener: title, hook, premise, format, twist, estimated_duration, rationale.

PATRONES:
{patterns}
'''
