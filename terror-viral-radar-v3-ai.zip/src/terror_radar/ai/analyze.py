from .factory import get_provider
from ..database.connection import connect

def analyze_with_ai(limit=100,provider_name=None):
    provider=get_provider(provider_name)
    if not provider: return 0
    c=connect()
    rows=c.execute("SELECT * FROM shorts WHERE transcript!='' OR title IS NOT NULL ORDER BY views DESC LIMIT ?",(limit,)).fetchall()
    done=0
    for r in rows:
        try:
            result=provider.analyze_short(r["title"] or "",r["description"] or "",r["transcript"] or "")
            d=result.data
            c.execute("UPDATE analyses SET hook_type=?,topic=?,format=?,hook_score=?,confidence=? WHERE short_id=?",
                      (d.get("hook_type","ai"),d.get("topic","other"),d.get("format","other"),
                       float(d.get("hook_strength",70) or 70),min(99,max(50,float(d.get("originality",70) or 70))),r["id"]))
            done+=1
        except Exception as e:
            print("AI error:",r["video_id"],e)
    c.commit();c.close();return done
