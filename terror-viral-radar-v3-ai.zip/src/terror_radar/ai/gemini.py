import json
from .base import AIProvider,AIResult
from .prompts import ANALYZE_PROMPT,IDEAS_PROMPT

class GeminiProvider(AIProvider):
    name="gemini"
    def __init__(self,api_key,model=None):
        super().__init__(api_key,model or "gemini-2.5-flash")
    def _model(self):
        from google import genai
        return genai.Client(api_key=self.api_key).models
    def _json(self,text):
        try:return json.loads(text)
        except Exception:
            m=text.find("{"); n=text.rfind("}")
            return json.loads(text[m:n+1]) if m>=0 and n>m else {"raw":text}
    def _generate(self,prompt):
        from google import genai
        client=genai.Client(api_key=self.api_key)
        return client.models.generate_content(model=self.model,contents=prompt).text
    def analyze_short(self,title,description="",transcript=""):
        raw=self._generate(ANALYZE_PROMPT.format(title=title,description=description,transcript=transcript))
        return AIResult(self.name,self.model,self._json(raw),raw)
    def generate_ideas(self,patterns,count=20):
        raw=self._generate(IDEAS_PROMPT.format(count=count,patterns=json.dumps(patterns,ensure_ascii=False)))
        return AIResult(self.name,self.model,self._json(raw),raw)
