import json
from .base import AIProvider,AIResult
from .prompts import ANALYZE_PROMPT,IDEAS_PROMPT

class OpenAIProvider(AIProvider):
    name="openai"
    def __init__(self,api_key,model=None):
        super().__init__(api_key,model or "gpt-5-mini")
    def _client(self):
        from openai import OpenAI
        return OpenAI(api_key=self.api_key)
    def _json(self,text):
        try:return json.loads(text)
        except Exception:
            m=text.find("{"); n=text.rfind("}")
            return json.loads(text[m:n+1]) if m>=0 and n>m else {"raw":text}
    def analyze_short(self,title,description="",transcript=""):
        r=self._client().responses.create(model=self.model,input=ANALYZE_PROMPT.format(title=title,description=description,transcript=transcript))
        raw=r.output_text
        return AIResult(self.name,self.model,self._json(raw),raw)
    def generate_ideas(self,patterns,count=20):
        r=self._client().responses.create(model=self.model,input=IDEAS_PROMPT.format(count=count,patterns=json.dumps(patterns,ensure_ascii=False)))
        raw=r.output_text
        return AIResult(self.name,self.model,self._json(raw),raw)
