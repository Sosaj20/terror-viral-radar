import os
from .openai import OpenAIProvider
from .gemini import GeminiProvider
from .claude import ClaudeProvider

def get_provider(name=None):
    name=(name or os.getenv("AI_PROVIDER","none")).lower()
    key=os.getenv("AI_API_KEY","")
    if name=="openai": key=os.getenv("OPENAI_API_KEY") or key
    if name=="gemini": key=os.getenv("GEMINI_API_KEY") or key
    if name=="claude": key=os.getenv("ANTHROPIC_API_KEY") or key
    if name=="openai": return OpenAIProvider(key,os.getenv("AI_MODEL"))
    if name=="gemini": return GeminiProvider(key,os.getenv("AI_MODEL"))
    if name=="claude": return ClaudeProvider(key,os.getenv("AI_MODEL"))
    if name in ("none","off",""): return None
    raise ValueError(f"Proveedor AI no soportado: {name}")
