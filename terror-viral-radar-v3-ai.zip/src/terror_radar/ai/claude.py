import json
from .base import AIProvider,AIResult
from .prompts import ANALYZE_PROMPT,IDEAS_PROMPT

class ClaudeProvider(AIProvider):
    name="claude"
    def __init__(self,api_key,model=None):
        super().__init__(api_key,model or "claude-sonnet-4-20250514")
    def _client(self):
        from anthropic import Anthropic
        return Anthropic(api_key=self.api_key)
    def _json(self,text):
        try:return json.loads(text)
        except Exception:
            m=text.find("{"); n=text.rfind("}")
            return json.loads(text[m:n+1]) if m>=0 and n>m else {"raw":text}
    def _generate(self,prompt):
        r=self._client().messages.create(model=self.model,max_tokens=3000,messages=[{"role":"user","content":prompt}])
        return r.content[0].text
    def analyze_short(self,title,description="",transcript=""):
        raw=self._generate(ANALYZE_PROMPT.format(title=title,description=description,transcript=transcript))
        return AIResult(self.name,self.model,self._json(raw),raw)
    def generate_ideas(self,patterns,count=20):
        raw=self._generate(IDEAS_PROMPT.format(count=count,patterns=json.dumps(patterns,ensure_ascii=False)))
        return AIResult(self.name,self.model,self._json(raw),raw)
