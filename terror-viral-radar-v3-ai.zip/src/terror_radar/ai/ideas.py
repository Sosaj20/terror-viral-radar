from .factory import get_provider
from ..database.connection import connect
def ai_ideas(count=20,provider_name=None):
    p=get_provider(provider_name)
    if not p:return []
    c=connect()
    patterns=[dict(x) for x in c.execute("SELECT * FROM patterns ORDER BY avg_score DESC LIMIT 30")]
    result=p.generate_ideas(patterns,count)
    ideas=result.data.get("ideas",[])
    for i in ideas:
        c.execute("INSERT INTO ideas(title,hook,topic,format,rationale,source_pattern) VALUES(?,?,?,?,?,?)",
                  (i.get("title"),i.get("hook"),i.get("topic","terror"),i.get("format","short"),i.get("rationale") or i.get("premise"),"ai"))
    c.commit();c.close();return ideas
