import re
PATTERNS=[
("warning",r"\b(?:nunca|never|no hagas|don't|si escuchas|if you hear)\b"),
("curiosity_gap",r"\b(?:nadie sabe|no one knows|lo que encontró|what he found|esto ocurrió|this happened)\b"),
("direct_threat",r"\b(?:detrás de ti|behind you|te está mirando|it's watching)\b"),
("time_specific",r"\b(?:a las|at)\s+\d"),
("question",r"\?")
]
def hook(text):
    t=(text or "")[:500].lower()
    hits=[n for n,p in PATTERNS if re.search(p,t)]
    return (hits[0] if hits else "open_loop",min(100,55+12*len(hits)))
