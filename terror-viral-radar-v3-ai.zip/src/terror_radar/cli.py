import argparse
def main():
    p=argparse.ArgumentParser(prog="terror-radar");s=p.add_subparsers(dest="cmd")
    a=s.add_parser("add-channel");a.add_argument("url")
    for name in ["snapshot","analyze","patterns","ideas","export","web","ai-analyze","ai-ideas"]:s.add_parser(name)
    ai=s.add_parser("ai-analyze");ai.add_argument("--provider",default=None);ai.add_argument("--limit",type=int,default=100)
    aid=s.add_parser("ai-ideas");aid.add_argument("--provider",default=None);aid.add_argument("--count",type=int,default=20)
    x=p.parse_args()
    if x.cmd=="add-channel":
        from .ingestion.channel import add_channel;print("Entradas:",add_channel(x.url))
    elif x.cmd=="snapshot":
        from .snapshots.capture import capture_all;print("Snapshots:",capture_all())
    elif x.cmd=="analyze":
        from .scoring.analyze import analyze_all;print("Analizados:",analyze_all())
    elif x.cmd=="patterns":
        from .patterns.discover import discover
        for r in discover():print(r["pattern_type"],r["pattern_key"],round(r["avg_score"],1))
    elif x.cmd=="ideas":
        from .ideas.generate import generate
        for r in generate():print(r["title"],"|",r["hook"])
    elif x.cmd=="export":
        from .reports.export import export_json,export_csv;print(export_json());print(export_csv())
    elif x.cmd=="ai-analyze":
        from .ai.analyze import analyze_with_ai;print("AI analizados:",analyze_with_ai(x.limit,x.provider))
    elif x.cmd=="ai-ideas":
        from .ai.ideas import ai_ideas
        for i in ai_ideas(x.count,x.provider):print(i.get("title"),"|",i.get("hook"))
    elif x.cmd=="web":
        from .web.app import run;run()
    else:p.print_help()
