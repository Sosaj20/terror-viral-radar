import yt_dlp
def extract_channel(url):
    with yt_dlp.YoutubeDL({"quiet":True,"skip_download":True,"extract_flat":True}) as ydl:
        return ydl.extract_info(url.rstrip("/")+"/shorts",download=False)
def extract_video(url):
    with yt_dlp.YoutubeDL({"quiet":True,"skip_download":True}) as ydl:
        return ydl.extract_info(url,download=False)
