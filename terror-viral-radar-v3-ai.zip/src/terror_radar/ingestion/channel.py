from .youtube import extract_channel
from ..database.connection import connect
def add_channel(url):
    info=extract_channel(url);c=connect()
    c.execute("INSERT OR IGNORE INTO channels(youtube_id,name,url,subscribers) VALUES(?,?,?,?)",
              (info.get("id"),info.get("channel") or info.get("uploader"),url,info.get("channel_follower_count") or 0))
    cid=c.execute("SELECT id FROM channels WHERE youtube_id=?",(info.get("id"),)).fetchone()[0]
    n=0
    for e in info.get("entries") or []:
        if not e or not e.get("id"): continue
        c.execute("INSERT OR IGNORE INTO shorts(channel_id,video_id,title,url,duration,views,likes,comments,published_at,description,thumbnail_url) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                  (cid,e["id"],e.get("title"),e.get("webpage_url") or f"https://youtube.com/watch?v={e['id']}",
                   e.get("duration") or 0,e.get("view_count") or 0,e.get("like_count") or 0,e.get("comment_count") or 0,
                   e.get("upload_date"),e.get("description"),e.get("thumbnail")))
        n+=1
    c.commit();c.close();return n
