# Terror Viral Radar V3

Motor de descubrimiento de Shorts de terror:
- snapshots históricos
- rendimiento relativo
- velocidad
- engagement
- outliers
- hooks
- temas y formatos
- patrones ganadores
- generación de ideas
- dashboard/API
- exportación

## Uso
```bash
pip install -e ".[dev]"
terror-radar add-channel "https://www.youtube.com/@Canal"
terror-radar snapshot
terror-radar analyze
terror-radar patterns
terror-radar ideas
terror-radar web
```
